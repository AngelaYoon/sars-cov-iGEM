# Auspice built documentation to be served by GitHub pages.

Files in this folder should not be modified by hand -- they are generated from within the `docs-src` directory.
