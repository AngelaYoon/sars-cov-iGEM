const version = "2.19.0";

module.exports = {
  version
};
