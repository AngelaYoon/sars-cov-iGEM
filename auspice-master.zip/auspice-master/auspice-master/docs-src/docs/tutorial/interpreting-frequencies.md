---
title: Interpreting the frequencies panel
---

> TODO