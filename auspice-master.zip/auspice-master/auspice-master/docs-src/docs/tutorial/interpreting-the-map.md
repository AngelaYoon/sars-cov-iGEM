---
title: Interpreting the map
---

> TODO

* how are transmission lines created
* winner takes all -- uncertainty is not conveyed
* deme sizes