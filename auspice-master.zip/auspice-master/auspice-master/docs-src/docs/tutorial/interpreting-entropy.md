---
title: Interpreting the entropy panel
---

> TODO