---
title: "Example of markdown file which has caused issues in the past"
date: "June 2020"
dataset: "https://nextstrain.org/zika"
abstract: "This narrative was incorrectly parsed by auspice v2.16.0 (and earlier) such that it doesn't even render."
---

# [Summary](https://nextstrain.org/zika)

The problem is (was) the following lines -- adding a character(s) to each line following the link syntax fixes the problem.

Table of Contents:  
1. [Some link](https://nextstrain.org)
